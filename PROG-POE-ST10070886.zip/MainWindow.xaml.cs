﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeAppWPF
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
            LoadRecipes();
        }

        private void LoadRecipes()
        {
            lvRecipes.ItemsSource = recipes;
        }

        private void btnEnterRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipe addRecipe = new AddRecipe();
            if (addRecipe.ShowDialog() == true)
            {
                recipes.Add(addRecipe.NewRecipe);
                LoadRecipes();
                MessageBox.Show("Recipe added successfully!");
            }
        }

        private void btnDisplayAll_Click(object sender, RoutedEventArgs e)
        {
            string recipeDetails = "All Recipes:\n\n";
            foreach (var recipe in recipes)
            {
                recipeDetails += $"{recipe.Name}\n";
            }
            MessageBox.Show(recipeDetails);
        }

        private void btnDisplayByName_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to display:", "Display Recipe by Name", "");
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                string recipeDetails = $"Recipe Name: {recipe.Name}\n";
                recipeDetails += new string('-', 50) + "\n"; // Add line
                recipeDetails += "Ingredients:\n";
                foreach (var ingredient in recipe.Ingredients)
                {
                    recipeDetails += $"- Name: {ingredient.Name}\n";
                    recipeDetails += $"  Quantity: {ingredient.Quantity}\n"; // Unit on its own line
                    recipeDetails += $"  Unit: {ingredient.Unit}\n"; // Unit on its own line
                    recipeDetails += $"  Calories: {ingredient.Calories}\n";
                    recipeDetails += $"  Food Group: {ingredient.FoodGroup}\n";
                    recipeDetails += new string('-', 50) + "\n"; // Add line
                }
                MessageBox.Show(recipeDetails);
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to scale:", "Scale Recipe", "");
            Recipe recipeToScale = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToScale != null)
            {
                string scaleInput = Microsoft.VisualBasic.Interaction.InputBox("Enter scale factor (0.5, 2, or 3):", "Scale Factor", "");
                double scale;
                if (double.TryParse(scaleInput, out scale))
                {
                    if (scale == 0.5 || scale == 2 || scale == 3)
                    {
                        // Scale the quantities of ingredients
                        foreach (var ingredient in recipeToScale.Ingredients)
                        {
                            ingredient.Quantity *= scale;
                        }
                        MessageBox.Show($"Recipe '{recipeName}' scaled by {scale}.");
                    }
                    else
                    {
                        MessageBox.Show("Invalid scale factor. Please enter 0.5, 2, or 3.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid input. Please enter a number.");
                }
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to reset quantities:", "Reset Quantities", "");
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipe != null)
            {
                // Reset quantities for the recipe
                foreach (var ingredient in recipe.Ingredients)
                {
                    ingredient.Quantity = 0; // You can set the quantity to whatever default value you prefer
                }
                MessageBox.Show($"Quantities reset for recipe '{recipeName}'.");
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnClearData_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to clear data:", "Clear Data by Name", "");
            Recipe recipeToRemove = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToRemove != null)
            {
                recipes.Remove(recipeToRemove);
                LoadRecipes();
                MessageBox.Show($"Data cleared for recipe '{recipeName}'.");
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}