﻿namespace RecipeAppWPF
{
    public class Ingredient
    {
        public string Name { get; set; }
        public string FoodGroup { get; set; }
        public int Calories { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }

        public Ingredient(string name, string foodGroup, int calories, double quantity, string unit)
        {
            Name = name;
            FoodGroup = foodGroup;
            Calories = calories;
            Quantity = quantity;
            Unit = unit;
        }
    }
}
