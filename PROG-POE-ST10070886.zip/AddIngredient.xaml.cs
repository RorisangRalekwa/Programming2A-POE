﻿using System.Windows;

namespace RecipeAppWPF
{
    public partial class AddIngredient : Window
    {
        public Ingredient NewIngredient { get; private set; }

        public AddIngredient()
        {
            InitializeComponent();
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtIngredientName.Text) &&
                !string.IsNullOrEmpty(txtFoodGroup.Text) &&
                int.TryParse(txtCalories.Text, out int calories) &&
                double.TryParse(txtQuantity.Text, out double quantity) &&
                !string.IsNullOrEmpty(txtUnit.Text))
            {
                NewIngredient = new Ingredient(txtIngredientName.Text, txtFoodGroup.Text, calories, quantity, txtUnit.Text);
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Please fill in all fields with valid values.");
            }
        }
    }
}


