﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class AddRecipe : Window
    {
        // Define public properties for Ingredients and Steps
        public List<Ingredient> Ingredients { get; private set; }
        public List<string> Steps { get; private set; }

        public Recipe NewRecipe { get; private set; }

        public AddRecipe()
        {
            InitializeComponent();
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
            lvIngredients.Visibility = Visibility.Collapsed; // Initially hide the ListView
        }

        private void txtRecipeName_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Show the ListView when the recipe name is entered
            if (!string.IsNullOrWhiteSpace(txtRecipeName.Text))
            {
                lvIngredients.Visibility = Visibility.Visible;
            }
        }

        private void btnAddIngredient_Click(object sender, RoutedEventArgs e)
        {
            AddIngredient addIngredientWindow = new AddIngredient();
            if (addIngredientWindow.ShowDialog() == true)
            {
                Ingredients.Add(addIngredientWindow.NewIngredient);
                lvIngredients.Items.Refresh();
            }
        }

        private void btnAddStep_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtStep.Text))
            {
                Steps.Add(txtStep.Text);
                lvSteps.Items.Refresh();
                txtStep.Clear();
            }
        }

        private void btnSaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtRecipeName.Text))
            {
                MessageBox.Show("Recipe name cannot be empty.");
                return;
            }

            if (Ingredients.Count == 0)
            {
                MessageBox.Show("Please add at least one ingredient.");
                return;
            }

            if (Steps.Count == 0)
            {
                MessageBox.Show("Please add at least one step.");
                return;
            }

            NewRecipe = new Recipe(txtRecipeName.Text, Ingredients, Steps);
            DialogResult = true;
            Close();
        }
    }
}